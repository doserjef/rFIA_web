#############################################
##
##  Status & Trends in Forest Condition
##        along APPA Corridor
##
##          Sample Script
##
##    Hunter Stanke & Andrew Finley
##          24 October 2019
##
##
#############################################

## Load the rFIA package
library(rFIA)
library(rgdal)

## How many cores do you have?
parallel::detectCores(logical = FALSE)
## How many do you want to use?
cores <- 1

## Set a local working directory
setwd('/home/hunter/NPS/AT_Summary/')

## Download and save the FIA data for each state which intersects APPA
at <- getFIA(states = c('CT', 'GA', 'ME', 'MD', 'MA', 'NH', 'NJ', 'NY', 'NC', 'PA', 'TN', 'VT', 'VA'),
             dir = './FIA/', nCores = cores)

## Load Ecoregion polygons
eco <- readOGR('./ecoregions/', 'at_ecoSub')


## A subset with matching Evaluation years across the region
atMatch <- clipFIA(at, matchEval = TRUE, mostRecent = FALSE)


#### Temporal Trends ####
ss <- standStruct(atMatch, polys = eco, tidy = FALSE, nCores = cores)
tpaS <- tpa(atMatch, polys = eco, bySpecies = TRUE, treeType = 'live', treeDomain = DIA >= 5, nCores = cores)
tpa <- tpa(atMatch, polys = eco, treeType = 'live', treeDomain = DIA >= 5, nCores = cores)
div <- diversity(atMatch, polys = eco, nCores = cores, treeDomain = DIA >= 5)
gmS <- growMort(atMatch, polys = eco, bySpecies = TRUE, nCores = cores, treeDomain = DIA >= 5)
gm <- growMort(atMatch, polys = eco, nCores = cores, treeDomain = DIA >= 5)
vrS  <- vitalRates(atMatch, polys = eco, bySpecies = TRUE, nCores = cores, treeDomain = DIA >= 5)
vr  <- vitalRates(atMatch, polys = eco, nCores = cores, treeDomain = DIA >= 5)
bioS <- biomass(atMatch, polys = eco, bySpecies = TRUE, nCores = cores, treeDomain = DIA >= 5)
bio <- biomass(atMatch, polys = eco, nCores = cores, treeDomain = DIA >= 5)
regenS <- tpa(atMatch, polys = eco, bySpecies = TRUE, treeType = 'live', treeDomain = DIA < 5, nCores = cores)
regen <- tpa(atMatch, polys = eco, treeType = 'live', treeDomain = DIA < 5, nCores = cores)
snag <- tpa(atMatch, polys = eco, treeType = 'dead', treeDomain = DIA >= 5, nCores = cores)
snagV <- biomass(atMatch, polys = eco, treeType = 'dead', treeDomain = DIA >= 5, nCores = cores)
snagLD <- tpa(atMatch, polys = eco, treeType = 'dead', treeDomain = DIA >= 11.81102, nCores = cores)
snagVLD <- biomass(atMatch, polys = eco, treeType = 'dead', treeDomain = DIA >= 11.81102, nCores = cores)
dw <- dwm(atMatch, polys = eco, tidy = FALSE, nCores = cores)
inv <- invasive(atMatch, polys = eco, nCores = cores)

# Save all dataframes as .csv
write.csv(ss, './results/ss.csv')
write.csv(div, file = './results/div.csv')
write.csv(tpaS, file = './results/tpaS.csv')
write.csv(tpa, file = './results/tpa.csv')
write.csv(gmS, file = './results/gmS.csv')
write.csv(gm, file = './results/gm.csv')
write.csv(vrS, file = './results/vrS.csv')
write.csv(vr, file = './results/vr.csv')
write.csv(bioS, file = './results/bioS.csv')
write.csv(bio, file = './results/bio.csv')
write.csv(regenS, file = './results/regenS.csv')
write.csv(regen, file = './results/regen.csv')
write.csv(snag, file = './results/snag.csv')
write.csv(snagV, file = './results/snagV.csv')
write.csv(snagLD, file = './results/snagLD.csv')
write.csv(snagVLD, file = './results/snagVLD.csv')
write.csv(dw, file = './results/dw.csv')
write.csv(inv, file = './results/inv.csv')


